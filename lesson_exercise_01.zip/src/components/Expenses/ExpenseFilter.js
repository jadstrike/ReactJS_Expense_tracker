import { DatePicker, Space } from "antd";
import moment from "moment";

const ExpenseFilter = (props) => {
  const dropdownChangeHandler = (date) => {
    // date = date.$y.toLocaleDateString();
    console.log(date);
    console.log(moment(date).format("YYYY"));
    const selectedYear = moment(date).format("YYYY");

    props.onChangeFilter(selectedYear);
  };
  return (
    <Space direction="vertical">
      <DatePicker
        value={props.selected}
        onChange={dropdownChangeHandler}
        picker="year"
      />
    </Space>
  );
};

export default ExpenseFilter;
